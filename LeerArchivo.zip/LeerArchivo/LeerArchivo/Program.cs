﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeerArchivo
{
    class Program
    {
        static void Main(string[] args)
        {
            Principal P = new Principal();
            P.Menu();
        }
    }
}
