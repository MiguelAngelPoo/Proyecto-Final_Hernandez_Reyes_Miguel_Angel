﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeerArchivo
{
    public class Datos_Pc
    {
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string Modelo { get; set; }
        public int Ram { get; set; }
        public string Procesador { get; set; }
        public string Tarjeta_Grafica { get; set; }
    }
}
